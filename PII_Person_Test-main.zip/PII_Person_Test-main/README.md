![UCU](./assets/logo-ucu.png)
# Debug & Test
## Programación II
### FIT—Universidad Católica del Uruguay

Código de ejemplo del tema debug &amp; test.

Este ejemplo usa la clase Person que ya conoces de repos anteriores. La tarea consiste en agregar casos de prueba para verificar que no se pueda asignar cédulas inválidas; y que se puedan asignar cuando sean válidas.

Agreguen todas las pruebas que consideren necesarias.

Un método de prueba por cada caso a probar.